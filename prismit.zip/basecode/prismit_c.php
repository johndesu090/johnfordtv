<?php
// Heading
$_['heading_title']    = 'Recommended Products';

// Text
$_['text_module']      = 'module';
$_['text_success']     = 'Success: You have modified,Recommended Products';
$_['text_content_top']    = 'Content Top';
$_['text_content_bottom'] = 'Content Bottom';

// Entry
$_['entry_category']      = 'Category:';
$_['entry_limit']         = 'limit:'; 
$_['entry_image']         = 'Image (widht x height):';
$_['entry_layout']        = 'Layout:';
$_['entry_position']      = 'Position:';
$_['entry_status']        = 'Status:';
$_['entry_sort_order']    = 'Sort Order:';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify,Recommended Products!';
?>