#!/bin/bash
# JohnFordTV's CDN Script
# © Github.com/johndesu090
# Thanks for using this script, Enjoy Highspeed CDN Service

# Kill ffmpeg live encoder
sudo killall ffmpeg

# Remove playlist cache
rm -rf /var/www/html/web/cdnlive-33554180976
mkdir -p /var/www/html/web/cdnlive-33554180976

# Start encoding
ffmpeg -nostdin -loglevel panic -headers "Referer: https://goperya.net/" -i "https://d2buxbq030tnlf.cloudfront.net/livecf/pulaasul/playlist.m3u8" -c copy -hls_flags delete_segments "/var/www/html/web/cdnlive-33554180976/playlist.m3u8" 2> /dev/null &
# Go back to root DIR
exit 1
