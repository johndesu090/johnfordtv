   ____                   __      __ _____   _   _ 
  / __ \                  \ \    / /|  __ \ | \ | |
 | |  | | _ __    ___  _ __\ \  / / | |__) ||  \| |
 | |  | || '_ \  / _ \| '_ \\ \/ /  |  ___/ | . ` |
 | |__| || |_) ||  __/| | | |\  /   | |     | |\  |
  \____/ | .__/  \___||_| |_| \/    |_|     |_| \_|
         | |
         |_|


		Jerome Laliag (c)


##################################################

SA MAG UUPDATE!
RECOMMEND CONNECTION: WIFI KUNG WALANG WIFI ANG IYONG COMPUTER OR LAPTOP, WAG MAG PM NA MATAGAL MAG INSTALLING, MABAGAL KASI SA LAN CABLE KAPAG NAKA ADB PUSH.
DO UNINSTALL - INSTALL

##################################################

` . DONATION
 GCASH: 09324247230
 PAYMAYA: 09324247230
 SUN PREPAID: 09324247230
 GLOBE PREPAID: 09565595801

` . CONTACT
 SUN PREPAID: 09324247230
 GLOBE PREPAID: 09565595801
 FACEBOOK: https://www.facebook.com/jerome.laliag.90
 YAHOO! MAIL: jeromelaliag@yahoo.com
 YOUTUBE: https://youtube.com/user/Jeromelaliag/
 INSTAGRAM: https://www.instagram.com/jeromelaliagg/

##################################################

` . AUTO SCRIPT FOR CREATING CONFIG IN VPS SERVER ( OpenVPN / OpenVPN - SSL / sTunnel )

Note: Bago nyo irun ang script na ito, dapat naka "sudo -i" na kayo or root mode at dapat fresh ang inyong VPS SERVER or hindi pa naiinstallan ng kung ano ano.

Video Tutorial: https://www.youtube.com/watch?v=96oZFgf6nBY

Auto Script (USE UBUNTU 16 X64) Iyes lang kapag nag ask. At imonitor ang logs or output, lalabas kasi sa script ang username na openvpn at password na random.

wget "https://www.dropbox.com/s/cgzgjkdnsxgqqw2/openvpn.sh?dl=1" -O openvpn.sh && chmod 777 openvpn.sh && ./openvpn.sh

Add User in OpenVPN (Change USERNAMEHERE to your username and change PASSWORDHERE to your password.)

useradd USERNAMEHERE

echo "USERNAMEHERE:PASSWORDHERE" | chpasswd

Change User Password in OpenVPN(Change USERNAMEHERE to your username and change PASSWORDHERE to your password.)

echo "USERNAMEHERE:PASSWORDHERE" | chpasswd

######## Download your config files here! ########

~> http://VPSIPADDRESS/openvpn.ovpn - Normal config
~> http://VPSIPADDRESS/openvpnssl.ovpn - Config with stunnel
~> http://VPSIPADDRESS/stunnel.conf - Stunnel config file
~> http://VPSIPADDRESS/openvpn.tgz - All config

##################################################

Note: Pwede nyo ito ishare sa iba, lagyan nyo lang ng credits para hindi naman nakakahiya sa akin. :)

##################################################

* Sa mga new user's or fresh install ang firmware sa modem.
  Open install.cmd para mainstall sa inyong modem ang OpenVPN Client.

* Sa mga mag uupdate ng openvpn client sa modem.
  Do uninstall.cmd to uninstall and install.cmd to install.

##################################################

` . Problem encountered
 Kung may naka set na password sa inyong telnet, iremove nyo muna para mag enable ulit ang adb.
 How to enable?
 Goto telnet 192.168.8.1
 Login: root
 Password: Yung sinet nyo nung nag "mount -o remount, rw /system && busybox passwd"
 Tapos iexecute nyo ang command na ito para maremove ang password. "mount -o remount, rw /system && busybox passwd -d root"
 Then "reboot".

##################################################

` . Kung nag kakaroon kayo ng problema sa oras ng inyong modem or hindi gumana ang openvpn sa starup due to incorrect date and time.
 Eto gamitin nyong firmware: https://www.dropbox.com/sh/5w14nfhz5mtnsl9/AAC98Zfw6HmV4hDetpv06AHxa?dl=1
 How to flash this firmware?
 Watch: https://www.youtube.com/watch?v=Pbrh6cfIsto&t=341s
 Tutorial: https://www.dropbox.com/s/fxjt5lak2ye7v0h/okkkkkkkk.txt?dl=1
 Pagkatapos nyo maflash ang firmware, punta kayo sa admin ng modem.
 http://192.168.8.1/ Username: admin Password: admin
 Tapos update, at iupload nyo ang B315s-22_Update_WEBUI_21.313.05.00.00_Mod1.5.bin sa B315 na folder.
 Kapag tapos na magreboot ang modem or tapos na magupdate, ireset nyo ang modem. Press nyo lang yung button na nakalubog sa likod.

##################################################



	` . OpenVPN Portal
	 URL: http://192.168.8.1:8080/
	 Username: admin
	 Password: admin

	WAN IP Address - eto yung ip address ng modem nyo, ang ip na eto ang galing sa telcos or leases ng tower.

	stunnel Status - dito mo malalaman kung running ang stunnel client sa inyong modem.

	OpenVPN Status - dito mo malalaman kung running ang openvpn client sa inyong modem.

	VPN Status - dito mo malalaman kung connected kana sa server ng openvpn.

	VPN IP Address - eto yung ip address leases na binigay ng openvpn server.

	Download / Upload - eto yung actual usage nyo gamit ang vpn.

	OVPN Config Uploader - dito mo iuupload ang .ovpn config mo sa openvpn, dapat tama ang format para may logs na lumabas. Kung walang logs na lumabas, may mali sa config mo.

	Set Password - ang option na ito ay dipende sa config mo. Kung may auth-user-pass sa line, kelangan mo fillupan to.

	OpenVPN Option - dito mo icoconnect at ididisconnect ang connection sa openvpn.

 	OpenVPN Startup - kapag naka enable, plug and play na ang modem nyo. Kapag naka disable ito, need nyo pang iconnect, or iaaccess nyo pa ang portal para kumonek.

	stunnel Config Uploader - dito mo iuupload ang .conf config mo sa stunnel.

	stunnel Option -  dito mo istart at istop ang connection sa sTunnel.

	stunnel Startup - kapag naka enable, plug and play na ang modem nyo. Kapag naka disable ito, need nyo pang iconnect, or iaaccess nyo pa ang portal para kumonek.

	Device Option - eto ang mga options sa device natin.

	Change WAN IP - kapag hindi mo gusto ang ip address, may blocking sa series na ip address or mabagal sa ip address leases na gamit mo, click mo lang ang option na ito para hindi mo na ireboot ang device sa pag papalit ng ip address.

	Reboot - para magrestart ang modem nyo.

	Power Off - para mamatay, mag poweroff or mag shutdown ang modem nyo. Eto ang purpose ng power off sa taas ng modem natin.

	Logs - dito mo makikita ang output logs ng openvpn client.

	Copy Logs - para macopy ang full logs output na nasa textarea.

	Clear Logs - para madelete ang logs output na nasa textarea.

	Change Password - dito mo papalitan ang default password ng openvpn portal.