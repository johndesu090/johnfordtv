#!/bin/bash
if ps aux | grep -i '[f]fmpeg' ; then
  echo "running" | tee -a checkerlog.txt
else
  echo "not running! restarting encoder..." | tee -a checkerlog.txt
  /bin/bash /root/activebak2.sh
fi

