#!/bin/bash
# JohnFordTV's StreamOven Premium Script
# © Github.com/johndesu090
iptables -A INPUT -s 15.235.141.83 -j DROP
iptables -A INPUT -s 51.79.159.67 -j DROP
iptables -A INPUT -s 139.99.91.138 -j DROP
iptables -A INPUT -s 165.22.60.93 -j DROP
iptables -A INPUT -s 15.235.184.133 -j DROP
iptables -A INPUT -s 159.89.200.152 -j DROP
iptables -A INPUT -s 139.99.91.29 -j DROP
iptables -A INPUT -s 139.99.90.113 -j DROP
iptables -A INPUT -s 15.235.167.71 -j DROP
iptables -A INPUT -s 146.190.108.40 -j DROP
iptables -A INPUT -s 154.26.135.158 -j DROP
iptables -A INPUT -s 51.79.157.227 -j DROP
iptables -A INPUT -s 51.79.251.83 -j DROP
iptables -A INPUT -s 51.79.251.8 -j DROP
iptables -A INPUT -s 51.79.158.36 -j DROP
iptables -A INPUT -s 188.166.254.53 -j DROP
iptables -A INPUT -s 206.189.150.109 -j DROP
iptables -A INPUT -s 15.235.184.124 -j DROP
iptables -A INPUT -s 15.235.167.95 -j DROP
iptables -A INPUT -s 128.199.65.231 -j DROP
iptables -A INPUT -s 178.128.55.169 -j DROP
iptables -A INPUT -s 154.26.135.161 -j DROP
iptables -A INPUT -s 143.198.206.100 -j DROP
iptables -A INPUT -s 15.235.184.174 -j DROP
iptables -A INPUT -s 51.79.251.169 -j DROP
iptables -A INPUT -s 15.235.167.74 -j DROP
iptables -A INPUT -s 154.26.135.162 -j DROP
iptables -A INPUT -s 51.79.161.225 -j DROP
iptables -A INPUT -s 154.26.135.159 -j DROP
iptables -A INPUT -s 154.26.135.85 -j DROP
iptables -A INPUT -s 15.235.167.72 -j DROP
iptables -A INPUT -s 206.189.152.193 -j DROP
iptables -A INPUT -s 139.99.89.120 -j DROP
iptables -A INPUT -s 159.223.65.33 -j DROP
iptables -A INPUT -s 139.99.90.244 -j DROP
iptables -A INPUT -s 154.26.135.160 -j DROP
iptables -A INPUT -s 51.79.158.242 -j DROP
iptables -A INPUT -s 51.79.158.136 -j DROP
iptables -A INPUT -s 51.79.207.93 -j DROP
iptables -A INPUT -s 51.79.159.38 -j DROP
iptables -A INPUT -s 178.128.104.172 -j DROP
iptables -A INPUT -s 207.148.75.14 -j DROP
iptables -A INPUT -s 146.190.106.10 -j DROP
iptables -A INPUT -s 139.99.89.127 -j DROP
iptables -A INPUT -s 15.235.167.4 -j DROP
iptables -A INPUT -s 15.235.167.73 -j DROP
iptables -A INPUT -s 51.79.156.101 -j DROP
iptables -A INPUT -s 51.79.251.44 -j DROP
iptables -A INPUT -s 51.79.160.225 -j DROP
iptables -A INPUT -s 15.235.146.79 -j DROP
iptables -A INPUT -s 154.26.135.86 -j DROP
iptables -A INPUT -s 51.79.251.202 -j DROP
iptables -A INPUT -s 154.26.135.157 -j DROP
iptables -A INPUT -s 207.148.75.14 -j DROP
iptables -A INPUT -s 146.190.102.28 -j DROP



