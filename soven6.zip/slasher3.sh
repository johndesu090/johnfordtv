#!/bin/bash
# JohnFordTV's CDN Script
# © Github.com/johndesu090
# Thanks for using this script, Enjoy Highspeed CDN Service

# Kill ffmpeg live encoder
#sudo killall ffmpeg

# Remove playlist cache
rm -rf /var/www/html/web/oglfight
mkdir -p /var/www/html/web/oglfight

# Start encoding
ffmpeg -nostdin -loglevel panic -headers "Referer: https://bpc2k.b-cdn.net/" -i "https://lino3.ultimatelivestreams.com:5443/lino3/lino3live/playlist.m3u8" -c copy -hls_flags delete_segments "/var/www/html/web/oglfight/playlist.m3u8" 2> /dev/null &
# Go back to root DIR
exit 1
