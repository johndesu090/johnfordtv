#!/bin/bash
# Thanks for using this script, Enjoy Highspeed CDN Service

# Kill ffmpeg live encoder
sudo killall ffmpeg

# Remove playlist cache
rm -rf /var/www/html/web/hackfight/streamoven*

# Start encoding
ffmpeg -i rtmp://172.31.6.168:1935/live/sabongworldwide99 -c:a aac -c:v copy -preset ultrafast -tune zerolatency -hls_key_info_file enc.keyinfo -hls_list_size 4 -hls_time 1 -hls_flags delete_segments -nostdin -loglevel panic -hls_segment_filename "/var/www/html/web/hackfight/streamoven_licensed_chunk_%03d.ts" -hls_base_url "/hackfight/" "/var/www/html/web/hackfight/playlist.m3u8" 2> /dev/null &
# Go back to root DIR
exit 1
